#!/bin/bash

set -e

RESTART_DATE=$(date +%s -d  2025-01-05)
STOP_DATE=$(date +%s -d  2024-12-19)
if [ $(date +%s) -gt $STOP_DATE ] &&
   [ $(date +%s) -lt $RESTART_DATE ] ; then
        exit
fi


export REPLYTO=users@einsteintoolkit.org
#FROM=reminders@einsteintoolkit.org 
FROM=rhaas@illinois.edu
mail -r $FROM -s "Agenda for Thursday's Meeting" users@einsteintoolkit.org <<EOF
Please update the Wiki with agenda items for Thursday's meeting. Thanks!

https://docs.einsteintoolkit.org/et-docs/meeting_agenda

--The Maintainers
EOF

date >>/home/rhaas/tmp/topics_reminder.log

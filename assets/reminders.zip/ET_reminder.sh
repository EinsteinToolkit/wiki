#!/bin/bash

set -e

RESTART_DATE=$(date +%s -d  2025-01-05)
STOP_DATE=$(date +%s -d  2024-12-19)
if [ $(date +%s) -gt $STOP_DATE ] &&
   [ $(date +%s) -lt $RESTART_DATE ] ; then
        exit
fi

# check for summer time in Europe
BERLIN_TIME=$(TZ='Europe/Berlin' date -d @$(TZ='America/Chicago' date -d '9:00am tomorrow' +%s) +"%H:%M")
if [ $BERLIN_TIME != "16:00" ] ; then
  DST_WARNING="
** DAYLIGHT SAVING TIME WARNING **
Please note that the US / EU has already / not yet transitioned to /
from daylight saving time. The phone call will be at $BERLIN_TIME Central EU
time.
"
fi

export REPLYTO=users@einsteintoolkit.org
#FROM=reminders@einsteintoolkit.org
FROM=rhaas@illinois.edu
mail -r $FROM  -s "Einstein Toolkit Meeting Reminder" users@einsteintoolkit.org <<EOF
Hello,

Please consider joining the weekly Einstein Toolkit phone call at
9:00 am US central time on Thursdays. For details on how to connect
and what agenda items are to be discussed, use the link below.
$DST_WARNING
https://docs.einsteintoolkit.org/et-docs/Main_Page#Weekly_Users_Call

--The Maintainers
EOF

date >>/home/rhaas/tmp/ET_reminder.log

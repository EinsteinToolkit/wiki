#!/bin/bash

set -e

RESTART_DATE=$(date +%s -d  2025-01-20)
STOP_DATE=$(date +%s -d  2025-01-14)
if [ $(date +%s) -gt $STOP_DATE ] &&
   [ $(date +%s) -lt $RESTART_DATE ] ; then
        exit
fi

# we alternate 10am / 11am CT
TIME_REF=$(date -d 2025-01-06 +%s)
if [ $(( ($(date +%s) - $TIME_REF) / (86400*7) % 2)) -ne 0 ] ; then
  MEETING_TIME="11am Thursday"
else
  MEETING_TIME="12pm Thursday"
fi

# check for summer time in Europe
BERLIN_TIME=$(TZ='Europe/Berlin' date -d @$(TZ='America/Toronto' date -d "$MEETING_TIME" +%s) +%_H)
EXPECTED_BERLIN_TIME=$(($(TZ='America/Toronto' date -d ${MEETING_TIME% *} +%_H) + 6))
if [ $BERLIN_TIME != $EXPECTED_BERLIN_TIME ] ; then
  DST_WARNING="
** DAYLIGHT SAVING TIME WARNING **
Please note that the US / EU has already / not yet transitioned to /
from daylight saving time. The phone call will be at $BERLIN_TIME Central EU
time.
"
fi

mail -r rhaas@illinois.edu -s "Weekly call at $MEETING_TIME Eastern time" carpetx-developers@lists.einsteintoolkit.org rhaas80@gmail.com <<EOF
Title: CarpetX developer call
When: $MEETING_TIME Eastern time
$DST_WARNING
Join Zoom Meeting
https://pitp.zoom.us/j/93861697232

Join by phone
(CA) +1 647-558-0588

Join using SIP
93861697232@zoomcrc.com
EOF

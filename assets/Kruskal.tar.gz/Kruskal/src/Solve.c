/* $Header$ */

#include <math.h>

#include <gsl/gsl_errno.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_roots.h>

#include "cctk.h"
#include "cctk_Parameters.h"



#define USE_DERIVS 0



struct params
{
  double y;
};



static double
Kruskal_f (double x,
           void * params);

static double
Kruskal_df (double x,
            void * params);

static void
Kruskal_fdf (double x,
             void * params,
             double * f,
             double * df);



/* Solve y = (x-1) exp(x) for x */

#warning "TODO: Solve y = (x-1) exp(x) for z = log(x) instead; this would force x to be positive automatically"

CCTK_FCALL CCTK_REAL
CCTK_FNAME (Kruskal_Solve) (CCTK_REAL const * restrict const y0)
{
  DECLARE_CCTK_PARAMETERS;
  
  double const y = * y0;
  
  struct params params;
  
#if USE_DERIVS
  gsl_function_fdf FDF;
  static gsl_root_fdfsolver * s = 0;
#else
  gsl_function F;
  static gsl_root_fsolver * s = 0;
#endif
  
  int status;
  int iter = 0, max_iter = 100;
  
#if USE_DERIVS
  double x0;
#else
  double x_lo, x_hi;
#endif
  double x;
  
  if (veryverbose)
  {
    CCTK_VInfo (CCTK_THORNSTRING, "y=%g", y);
  }
  
  params.y = y;
  
#if USE_DERIVS
  
  FDF.f = Kruskal_f;
  FDF.df = Kruskal_df;
  FDF.fdf = Kruskal_fdf;
  FDF.params = & params;
  
  if (! s)
  {
    s = gsl_root_fdfsolver_alloc (gsl_root_fdfsolver_steffenson);
  }
  x = log (y);
  gsl_root_fdfsolver_set (s, & FDF, x);
  
#else
  
  F.function = Kruskal_f;
  F.params = & params;
  
  if (! s)
  {
    s = gsl_root_fsolver_alloc (gsl_root_fsolver_brent);
  }
  x_lo = y <= 1 ? 0 : 0.5 * log (y);
  x_hi = log (y + 3);
  if (veryverbose)
  {
    CCTK_VInfo (CCTK_THORNSTRING, "   x in [%g,%g]", x_lo, x_hi);
  }
  gsl_root_fsolver_set (s, & F, x_lo, x_hi);  
  
#endif
  
  do
  {
    ++ iter;
#if USE_DERIVS
    x0 = x;
    status = gsl_root_fdfsolver_iterate (s);
    x = gsl_root_fdfsolver_root (s);
    status = gsl_root_test_delta (x, x0, 0, 1e-6);
#else
    status = gsl_root_fsolver_iterate (s);
    x_lo = gsl_root_fsolver_x_lower (s);
    x_hi = gsl_root_fsolver_x_upper (s);
    if (veryverbose)
    {
      CCTK_VInfo (CCTK_THORNSTRING,
                  "   iter %d   x in [%g,%g]", iter, x_lo, x_hi);
    }
    status = gsl_root_test_interval (x_lo, x_hi, 0, 1e-6);
#endif
  }
  while (status == GSL_CONTINUE && iter < max_iter);
  
  if (status != GSL_SUCCESS)
  {
    CCTK_WARN (2, "Kruskal solver did not converge");
  }
  
#if USE_DERIVS
#else
  x = gsl_root_fsolver_root (s);
#endif
  
  if (veryverbose)
  {
    CCTK_VInfo (CCTK_THORNSTRING,
                "   x=%g   y(x)=%g  diff=%g   iters=%d",
                x, (x-1)*exp(x), (x-1)*exp(x) - y, iter);
  }
  
  return x;
}



double
Kruskal_f (double const x,
           void * restrict const params0)
{
  struct params const * restrict const params = params0;
  return (x - 1) * exp (x) - params->y;
}

double
Kruskal_df (double const x,
            void * restrict const params0)
{
  struct params const * restrict const params = params0;
  return x * exp (x);
}

void
Kruskal_fdf (double const x,
             void * restrict const params0,
             double * restrict const f,
             double * restrict const df)
{
  struct params const * restrict const params = params0;
  double const t = exp (x);
  * f = (x - 1) * t - params->y;
  * df = x * t;
}
